ZoVerse Operator Dashboard Full Bind Pack

This package adds:
- Codex-based trigger script (for AI task chaining)
- Voice command (speech-to-text) integration
- Live UI logging terminal component

Bundle plugs directly into your Operator Dashboard.
