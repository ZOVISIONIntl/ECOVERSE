ZoClone Interface Scaffolding
This bundle includes a front-end HTML dashboard and a Node.js server.
Usage:
1. Run `npm install express` if needed
2. Launch the interface with: node server.js
3. Navigate to http://localhost:7777 to access your Operator Dashboard UI