EraScript Publishing Suite
This suite powers full-spectrum publishing and monetization for books, music, shows, poetry, and Codex content.

Includes:
- Legal Shells
- Copyright/IP Automation
- AI Consent Agreements
- Publishing Operator UI Hook
- Ownership loop integration to Nu Vizion Trust
